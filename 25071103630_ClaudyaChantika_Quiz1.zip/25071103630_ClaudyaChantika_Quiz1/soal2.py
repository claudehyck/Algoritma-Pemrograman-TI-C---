daftar_buku = [
    ["Algoritma dan Pemrograman", 2000],
    ["Basis Data", 2500],
    ["C++", 3000],
    ["Python", 5000],
    ["Struktur Data", 2200]
]